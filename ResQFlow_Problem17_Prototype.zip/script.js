const areas=[
 {location:"Vijayawada Flood Zone",priority:"High",need:"Drinking Water",required:1800,available:900},
 {location:"Guntur Relief Camp",priority:"High",need:"Food Packets",required:2200,available:1700},
 {location:"Eluru Affected Area",priority:"Medium",need:"Medical Kits",required:600,available:500},
 {location:"Machilipatnam Coastal Camp",priority:"Low",need:"Blankets",required:900,available:780}
];
const warehouses=[
 {name:"Central Warehouse",location:"Vijayawada",stock:"2,400 units",items:"Water • Food • Medical"},
 {name:"North Relief Store",location:"Guntur",stock:"1,950 units",items:"Food • Blankets"},
 {name:"Coastal Warehouse",location:"Machilipatnam",stock:"2,500 units",items:"Water • Medical • Blankets"}
];
const dispatches=[
 ["Vijayawada Flood Zone","High","Drinking Water","900","Central Warehouse","Pending"],
 ["Guntur Relief Camp","High","Food Packets","500","North Relief Store","Ready"],
 ["Eluru Affected Area","Medium","Medical Kits","100","Coastal Warehouse","Ready"],
 ["Machilipatnam Coastal Camp","Low","Blankets","120","Coastal Warehouse","Pending"]
];
function renderAreas(){
 const q=document.getElementById("search").value.toLowerCase();
 document.getElementById("areaList").innerHTML=areas.filter(a=>a.location.toLowerCase().includes(q)).map(a=>{
   const pct=Math.min(100,Math.round(a.available/a.required*100));
   return `<div class="area"><div class="row"><b>${a.location}</b><span class="priority ${a.priority.toLowerCase()}">${a.priority}</span></div><div class="muted">Need: ${a.need} • Required: ${a.required} • Available: ${a.available}</div><div class="progress"><div style="width:${pct}%"></div></div></div>`
 }).join("");
}
function renderWarehouses(){
 document.getElementById("warehouseList").innerHTML=warehouses.map(w=>`<div class="warehouse"><div class="row"><b>📦 ${w.name}</b><b>${w.stock}</b></div><div class="muted">${w.location} • ${w.items}</div></div>`).join("");
}
function renderDispatch(){
 document.getElementById("dispatchTable").innerHTML=dispatches.map(d=>`<tr><td>${d[0]}</td><td><span class="priority ${d[1].toLowerCase()}">${d[1]}</span></td><td>${d[2]}</td><td>${d[3]}</td><td>${d[4]}</td><td class="status ${d[5]==="Ready"?"ready":"pending"}">${d[5]}</td></tr>`).join("");
}
function openModal(){document.getElementById("modal").style.display="flex"}
function closeModal(){document.getElementById("modal").style.display="none"}
function addRequest(e){
 e.preventDefault();
 const loc=document.getElementById("location").value, res=document.getElementById("resource").value, qty=Number(document.getElementById("quantity").value), pri=document.getElementById("priority").value;
 areas.push({location:loc,priority:pri,need:res,required:qty,available:0});
 document.getElementById("areas").textContent=areas.length;
 document.getElementById("gaps").textContent=Number(document.getElementById("gaps").textContent.replace(",",""))+qty;
 renderAreas(); closeModal();
 document.getElementById("toast").textContent="Relief request created successfully!";
 document.getElementById("toast").style.display="block";
 setTimeout(()=>document.getElementById("toast").style.display="none",2500);
 e.target.reset();
}
renderAreas();renderWarehouses();renderDispatch();
