# ResQFlow – Disaster Relief Resource Coordination Platform

## Prototype
Frontend prototype for Problem Statement 17.

### Requirements covered
- Affected-area dashboard
- Resource gaps
- Available warehouse stock
- Suggested allocation/dispatch status
- Relief request form
- Priority levels
- Search
- Responsive UI
- Success feedback

### Run
1. Extract the ZIP.
2. Open `index.html` in Chrome/Edge.
3. Click **+ Add Relief Request** to test the prototype.

## Full-stack version
The final implementation can use:
- Java 17
- Spring Boot
- React.js
- REST APIs
- MySQL/PostgreSQL
- JPA/Hibernate
- Git/GitHub

Suggested backend flow:
React → REST API → Spring Boot Controller → Service → JPA Repository → Database → JSON → React.
